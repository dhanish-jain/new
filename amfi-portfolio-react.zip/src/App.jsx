import { useEffect, useState } from "react";

function App() {
  const [funds, setFunds] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedFund, setSelectedFund] = useState(null);
  const [units, setUnits] = useState("");
  const [value, setValue] = useState(null);

  useEffect(() => {
    loadFunds();
  }, []);

  async function loadFunds() {
    try {
      const res = await fetch(
        "https://api.allorigins.win/raw?url=https://portal.amfiindia.com/spages/NAVAll.txt"
      );
      const text = await res.text();

      const lines = text.split("\n");
      const parsed = [];

      lines.forEach((line) => {
        const parts = line.split(";");
        if (parts.length > 4 && parts[3] && parts[4]) {
          const nav = parseFloat(parts[4]);
          if (!isNaN(nav)) {
            parsed.push({
              name: parts[3].trim(),
              nav: nav,
            });
          }
        }
      });

      setFunds(parsed);
    } catch (err) {
      console.error("Error loading funds:", err);
    }
  }

  const filteredFunds = funds.filter((f) =>
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  function handleSelect(fund) {
    setSelectedFund(fund);
    setValue(null);
  }

  function calculate() {
    if (!selectedFund || !units) return;
    setValue((selectedFund.nav * parseFloat(units)).toFixed(2));
  }

  return (
    <div className="container">
      <h1>AMFI Portfolio Tracker</h1>

      <input
        type="text"
        placeholder="Search fund..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="fund-list">
        {filteredFunds.slice(0, 50).map((fund, index) => (
          <div
            key={index}
            className="fund-item"
            onClick={() => handleSelect(fund)}
          >
            {fund.name} (₹{fund.nav})
          </div>
        ))}
      </div>

      {selectedFund && (
        <div className="selected">
          <p>
            Selected: <b>{selectedFund.name}</b>
          </p>

          <input
            type="number"
            placeholder="Enter units"
            value={units}
            onChange={(e) => setUnits(e.target.value)}
          />

          <button onClick={calculate}>Calculate</button>
        </div>
      )}

      {value && (
        <div className="result">
          Portfolio Value: ₹{value}
        </div>
      )}
    </div>
  );
}

export default App;
